# TORQUE — PC Performance Suite

A Windows 10/11 performance suite for gamers. One click applies research-backed Windows, driver and in-game tweaks at three levels — **LOW / MED / MAX** — with a full preview first, and every change is backed up and revertible. Built for NVIDIA + Fortnite first, with VALORANT, Marvel Rivals, Apex, Rocket League, CS2 and Minecraft supported.

**First launch:** TORQUE asks you to create a password (or continue without one). You can change it or turn it off in Settings → Security.

---

## Run it

1. Copy `Torque.exe` anywhere, for example `C:\Tools\Torque\`. It's a single, self-contained file with no installer and no .NET download.
2. Double-click it and accept the admin prompt. It needs admin to change system settings.
3. Windows SmartScreen will probably say "Windows protected your PC", because the exe isn't code-signed. Click **More info → Run anyway**. A paid code-signing certificate removes this, which only matters if you ever distribute it.
4. Enter the password. On first launch, TORQUE offers to create a System Restore point. Say yes.

**Recommended first session (about 15 minutes):**
1. **Health Check.** Fix anything red. The real wins are your monitor's refresh rate, RAM at its EXPO speed, the monitor cable in the GPU (not the motherboard), and Resizable BAR.
2. **Benchmark Lab.** Record a 60-second **Before** run in Fortnite: Creative or a replay, same route.
3. **Optimize.** Pick **MAX** (or MED), click **Optimize**, review the preview, Apply. TORQUE does the Windows tweaks, NVIDIA driver profile, game configs (close your games first), debloat, startup cleanup, DNS and Game Boost by itself. Restart when it's done.
5. **Benchmark Lab.** Record an **After** run and compare avg FPS, 1% lows and 0.1% lows.

---

## What's inside

| Page | What it does |
|---|---|
| **Dashboard** | Live CPU, GPU, GPU temp, clocks, RAM, VRAM, disk and ping with sparklines. A tachometer "Optimization Score" (checklist completeness, not FPS). Top issues with one-click fixes. |
| **Optimize** | Four levels: **LOW** (safe essentials + max refresh rate + NVIDIA low-latency driver profile), **MED** (+ USB/PCIe/CPU latency power settings, debloat, startup cleanup, Balanced game configs) and **MAX** (+ Windows Low Latency Profile, fastest DNS, Competitive game configs, Game Boost) and **ULTRA** (+ every experimental tweak and GPU scheduling; warning + restart). One click; preview shows every old → new value and every automation. Optional restore point and temp cleanup. |
| **Games** | Auto-detects Fortnite, VALORANT, CS2, Apex, Rocket League, Marvel Rivals, CoD/Warzone, Roblox and Minecraft (Epic, Steam, Riot, Xbox and Battle.net paths, installed apps, running processes). **Auto-configure** per game: writes tuned settings into the game's own config file (Fortnite, VALORANT, Marvel Rivals, Apex, Rocket League, CS2, Minecraft), sets the Windows GPU preference and an NVIDIA per-game profile, and shows exactly what it set. Custom profiles for any .exe. Game Boost settings. |
| **Fortnite** | Writes `GameUserSettings.ini` directly, only while Fortnite is closed and with a backup first. Presets: **Competitive / Balanced / Visual (DX12)**. Switches **Performance rendering mode** directly (`[D3DRHIPreference] PreferredRHI=dx11 / PreferredFeatureLevel=es31`), turns on **Reflex On + Boost**, V-Sync and motion blur off, frame cap = monitor refresh or uncapped. |
| **Stretched Res** | 1750×1080, 1650×1080, 1440×1080 and 1280×1080. **One click:** creates the custom resolution through the NVIDIA driver API (keeps your monitor's native timing), sets Full-screen GPU scaling, switches the desktop with a 15-second keep-or-revert countdown, has a one-click "Back to native", sets Fortnite to Windowed Fullscreen, and can **auto-stretch only while Fortnite runs**. |
| **Benchmark Lab** | Intel PresentMon 2.6.0, bundled and checked against its official SHA-256 before every run. Avg FPS, 1% low, 0.1% low, stutter %, frame-time graph, and a saved Before/After comparison with % change. |
| **Tweaks Library** | Every tweak with its level, evidence rating (**Proven / Situational / Experimental**), risk, restart flag, live state, apply/revert, and a "what & why". Searchable and filterable. |
| **System** | Debloat (curated Safe / Caution / Protected list; Store, Xbox and Game Pass parts are protected). Startup apps (same switch as Task Manager). Services (curated, set to Manual, never Disabled). Privacy. |
| **Health Check** | Refresh rate below max (one-click fix), RAM below kit speed and Resizable BAR off (**Restart into BIOS** button — these are BIOS-only), monitor on the iGPU port, Resizable BAR, PCIe link width, driver age, HAGS, Game Mode, power plan, Game DVR, disk space, disabled page file (one-click restore), startup count, and VBS (reported only). Exportable system scan. |
| **Graphics** | Auto-detects NVIDIA or AMD. Driver, Resizable BAR, PCIe, live telemetry, and **automatic NVIDIA driver tuning** written into the driver profile database: Low Latency Mode On, V-Sync off, unlimited shader cache, high-performance texture filtering, driver FPS limiter off, and Prefer Maximum Performance per game. Undo restores your exact originals. |
| **Personalize** | Accent color (8 presets + custom hex), 5 animated backdrops (Redline, Ember, Carbon, Aurora, Blackout), glow, glass opacity, corner roundness, animation level and speed, sound effects (3 packs, volume, hover sounds), UI scale, start page. All live. |
| **Color Enhancer** | NVIDIA Digital Vibrance via NVAPI, plus brightness, contrast and gamma on any GPU. Presets (Competitive Pop, Vivid, Shadow Lift…). **Before/after split view** using a capture of your own screen or a built-in test pattern. "Use my current settings" reads your NVIDIA Control Panel values. Restore original, and optional re-apply at startup. |
| **Network** | DNS benchmark (Cloudflare, Google, Quad9, your current DNS) with one-click switch and restore. Ping, jitter and loss test. Flush DNS. |
| **Cleaner** | Temp files, Windows Update cache, crash dumps, error reports, Delivery Optimization cache, Recycle Bin, and optionally shader caches (with a stutter warning). Sizes are measured live. |
| **Backups & Restore** | Every TORQUE change set with its original values and a per-item Revert. **Revert everything.** System Restore point list, create a point, open System Restore. |
| **Activity Log** | Every change, timestamped and filterable. Export to .txt. |
| **Settings** | Tray behavior, start with Windows, change password, GPU vendor override, exclusion list editor. |
| **Tray** | Open, Game Boost on/off, current level, Lock, Exit. |

### New in v2.3
- **TORQUE on/off switch** in the sidebar: switching it off undoes everything TORQUE changed (same as Revert everything) and returns you to STOCK — perfect for recording a "before".
- **ULTRA level** above MAX: everything in MAX + every experimental tweak + hardware GPU scheduling. Shows a warning first and offers a restart afterwards. LOW/MED/MAX no longer include GPU scheduling (it needs a restart).
- **Custom setups per game:** pick Custom on any supported game and choose each setting yourself (rendering mode, shadows, Reflex, V-Sync…). Saved per game and used by Auto-configure and Optimize.
- **Loading indicators everywhere:** buttons show a spinner while working, plus a progress bar and status pill — nothing looks frozen.
- **Fixes:** Graphics page error on second visit; the level now drops to STOCK when everything is reverted; tweaks that were already Windows' own setting show "Windows already set" instead of looking stuck on; color sliders always work (moving them turns gamma on); engine-rev sound removed.

### New in v2.2
- **Permissions handled properly:** TORQUE checks it's running as administrator and offers **Restart as administrator** if not. Anything Windows blocks (protected registry keys, policies, Controlled folder access on Documents) is rolled back cleanly with a plain-English reason and a fix button.
- **Share your setup:** Settings → Share your setup exports a `.torque` profile (look, level, Game Boost, stretch, color). Importing applies the settings and offers the same optimization level — with the full preview first. No passwords, backups or file paths are included.
- **Global shortcuts (work in-game):** **Ctrl+Alt+B** toggles Game Boost, **Ctrl+Alt+T** opens TORQUE. Can be turned off in Settings.
- **Your own password:** no shared default password — each install creates its own, or skips it.

### New in v2.1: Low performance mode + efficiency
- **Personalize → Performance: Auto / Low performance / Full quality.** Auto switches to Low performance by itself in virtual machines, remote desktops and on PCs without full GPU rendering. Low performance keeps the same layout and colors but drops the animated background, glow effects and motion, and polls stats every 2 s.
- **Measured under software rendering (like a VM):** dashboard **~183% of a CPU core → ~7%**, lock screen **~130% → ~3%**, about **135 MB less RAM**.
- **Free efficiency in every mode:** the background freezes whenever TORQUE isn't the active window (e.g. while you're in a game), stats stop polling when the window is hidden, memory is handed back to Windows when you minimise, background blobs update at 8 fps (sub-pixel steps, invisible) and embers at 24 fps, hover glows are removed once they fade out, the temperature query runs every 5 s instead of every 1 s, and the exe is precompiled (ReadyToRun) so it uses less CPU at launch.

### New in v2: latency tweaks (from research)
| Tweak | Level | Evidence |
|---|---|---|
| Windows **Low Latency Profile** (feature 58989092, KB5094126+; via bundled hash-checked ViVeTool) — CPU boosts for 1–3 s on input/app launch | MAX | Situational (needs build 26100/26200.8655+, skipped otherwise) |
| USB selective suspend off | MED | Proven |
| PCIe link power management off | MED | Situational |
| CPU energy preference (EPP) = performance | MED | Situational |
| Network adapter Energy-Efficient Ethernet / power saving off | MED | Situational |
| Edge Startup Boost / background mode off | MED | Proven |
| Fastest keyboard repeat | LOW | Proven |
| Interrupt moderation off · GPU MSI mode · memory compression off · QoS DSCP 46 for games | opt-in | Experimental |

### Game Boost (MAX level or the sidebar switch)
While a profiled game runs, Game Boost:
- switches to the performance power plan
- mutes notifications
- raises the game's priority to High
- suspends the background apps **you** approved
- auto-stretches the resolution, if you turned that on

Everything is restored when the game closes. State is saved to disk, so if TORQUE is killed mid-game, it restores on next launch.

---

## Safety design

- **Restore point** on first launch and before every batch apply. TORQUE lifts Windows' one-per-24h limit so the point actually gets created.
- **Originals are captured once**, before the first change, so reverts always go back to your PC's real original state, even after re-applies.
- **Failed tweaks roll back** whatever part already applied.
- **Hard exclusions** (editable in Settings):
  - Java (Minecraft servers) and tunnels (Playit, ngrok, Cloudflare): a server running on the PC is never touched. Add your own folders/apps in Settings → Exclusions.
  - Logitech, NVIDIA, audio
  - Easy Anti-Cheat, BattlEye, Vanguard
  - Defender, Windows Update
- **Anti-cheat safe**: TORQUE never injects into games, never reads game memory, and never edits game binaries. The only game files it edits are the games' own settings files (.ini / .txt / .cfg), always with a backup and only while the game is closed.
- **Banned tweaks.** These are blocked in code even if someone adds them to the catalog:
  - forcing HPET / `useplatformclock`
  - disabling Defender, SmartScreen, UAC or CPU security mitigations
  - disabling Windows Update or the page file
  - registry "cleaners"
  - mass-disabling services
- **No telemetry.** The only network traffic is the DNS benchmark, the ping test, and links you click.
- **The password is a casual-access lock, not real security.** Only a salted PBKDF2-SHA256 hash (210k iterations) is stored, in `%ProgramData%\Torque\config.json`. Anyone with admin rights can delete that file to reset it.

All data lives in `%ProgramData%\Torque\`: config, backups and a rolling backup history, activity log, benchmarks, Fortnite ini backups, and the system scan.

---

## What to expect

- **The biggest FPS changes are the Health Check items and Fortnite's Performance rendering mode.** Performance mode is commonly 2–3× DirectX 12 FPS in competitive BR. RAM at its EXPO/XMP rated speed is often worth 5–15% in CPU-bound games.
- Windows tweaks mostly improve **consistency**: fewer background interruptions and better 1% lows. On a modern gaming PC, don't expect a big average-FPS jump from them alone.
- Experimental tweaks are off by default and labeled. Benchmark them, and revert any that don't help.
- Stretched res is mostly about feel. FPS gains are small when you're CPU-limited.

---

## Known limitations

- **CPU temperature** shows N/A on most desktops. Reading it needs a kernel driver, and TORQUE deliberately doesn't ship one (Defender flags them).
- **Not yet verified on every hardware combination:** NVIDIA driver profile writes (DRS), custom resolution creation, full-screen scaling (CCD API), Digital Vibrance and the Low Latency Profile flag. They use NVIDIA's/Microsoft's documented APIs, back up first and roll back on errors — and every one has an Undo.
- **EXPO and Resizable BAR are BIOS-only.** TORQUE can restart you straight into the BIOS, but the switch itself is yours to flip.
- **Monitor cable on the motherboard / GPU in a slower PCIe slot** are physical — TORQUE detects and reports them.
- **Game configs** only change keys that already exist in each file (Fortnite's rendering-mode keys are the exception). VALORANT is the odd one: Riot syncs some settings from the cloud, so a few may revert on login.
- **AMD GPUs** get Windows and game tuning but not driver tuning (ADLX not wired in yet).
- **CoD process names** change between releases. If Game Boost doesn't pick it up, add the exe as a custom profile.
- **Digital Vibrance uses NVAPI calls that couldn't be tested before delivery.** If vibrance doesn't change, gamma/contrast still work.
- The UI uses a custom Fluent-style theme (no WPF-UI package) and a solid graphite background instead of Mica.
- **HKCU settings** apply to the account that approved the admin prompt. Run TORQUE from your own admin account.

## Self-test
`Torque.exe --selftest C:\some\folder` runs 95 logic checks, including a full apply → revert-everything round trip (password hashing, exclusions, catalog and banned list, INI editing, benchmark math, DNS packets, RAM part-number parsing, gamma) and renders every page to PNG. It makes no system changes.

## Build from source
Needs the .NET 8 SDK. Run:

```
cd src/Torque
dotnet publish -c Release -o ../../dist
```

The output is a self-contained single-file `win-x64` exe with an admin manifest. PresentMon is embedded from `vendor/`.

Credits: Intel PresentMon 2.6.0 (MIT), ViVeTool 0.3.4 (GPL-3.0, unmodified, source: https://github.com/thebookisclosed/ViVe — licence in `licenses/`), NvAPIWrapper.Net (LGPL-3.0), Inter & Barlow fonts (OFL), Microsoft Fluent UI System Icons (MIT).

Screenshots were captured with `--demo` sample data (no real GPU on the build machine). The real app always shows your PC's real numbers.
